# Ansys ModelCenter (multi-simulation optimization) MCP

Per-product offline MCP server. See SKILL.md for usage.

* pip client: ansys-modelcenter-workflow
* top-level import: ansys.modelcenter
* kind: grpc
* env: ANSYS_ROOT
