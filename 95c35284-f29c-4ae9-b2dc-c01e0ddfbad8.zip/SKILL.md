---
name: ansys-modelcenter
display_name: "Ansys ModelCenter (multi-simulation optimization) (offline MCP)"
description: "Drive Ansys ModelCenter (multi-simulation optimization) over 3 offline MCP tools (modelcenter: status/launch/run). The pip client (ansys-modelcenter-workflow) ships in the venv and soft-imports, so the server never crashes when the product is absent. Use when an operator asks to probe, launch, or run ModelCenter (multi-simulation optimization), or to check ANSYS_ROOT / availability offline. ANSYS_ROOT (edit in mcp.json) must point at the Ansys install for real runs; a valid license is required."
---

# Ansys ModelCenter (multi-simulation optimization) — MCP usage skill

This MCP exposes **3 stdio tools** for **ModelCenter (multi-simulation optimization)**:

| tool | side effects | purpose |
|---|---|---|
| `ansys_modelcenter_status` | none | Is the pip client importable here? Is ANSYS_ROOT set? Always safe. |
| `ansys_modelcenter_launch` | connect/construct | Soft-import the client (`ansys.modelcenter`) and, best-effort, build the `(n/a)` object. Returns a JSON error — never an exception — if the SDK is missing, ANSYS_ROOT is unset, or (PyAEDT) the connect times out (30 s guard). |
| `ansys_modelcenter_run` | best-effort | Take a small `command` string; return the documented client call to issue. |

## Product facts
* **pip client package:** `ansys-modelcenter-workflow`
* **top-level import:** `ansys.modelcenter`
* **entry symbol:** `(none — use the client API)`
* **transport to product:** grpc
* TALKS TO A gRPC-EMBEDDED/INTERACTIVE ENGINE. The client package is in the venv; a running Ansys host process + valid license (ANSYS_ROOT) is needed for real work.

## Env vars (edit in mcp.json)
- **ANSYS_ROOT** — path to the Ansys installation on this host (e.g. `C:\ANSYS\v252\ansys_inc`). Required for real runs; a valid, checked-out ModelCenter (multi-simulation optimization) license must be available.

## Standard operator flow
1. `ansys_modelcenter_status` → confirm `ANSYS_ROOT` is set and the client is importable.
2. `ansys_modelcenter_launch` → confirm the client object constructs (a "matching install/license not reachable" JSON warning is expected on a dev box with only the pip package).
3. `ansys_modelcenter_run command="<concrete command>"` → get the exact client call / macro to issue against the live product.

## Launch / use recipe
```python
import ansys.modelcenter   # client for a ModelCenter project
```

## Error contract (JSON, never a crash)
- `ANSYS_PKG_MISSING` — client package not importable in the venv.
- `ANSYS_SDK_NOT_FOUND` — (distrib only) the root env var is unset or the path is missing.
- `LAUNCH_TIMEOUT` — (PyAEDT only) the GUI/COM connect exceeded 30 s.
- `LAUNCH_ERROR` / `IMPORT_ERROR` — import or construction failed; the note explains the missing prerequisite (usually a running Ansys host process + license at ANSYS_ROOT).

The status tool is side-effect free and is the right place to confirm offline state without an Ansys install.
