"""Ansys ModelCenter (multi-simulation optimization) MCP server (per-product, offline, self-contained).

Single-product split of the 30-product Ansys MCP. At module load this file
imports ONLY the stdlib + the `mcp` SDK. The ansys.modelcenter client package is
soft-imported inside tool bodies, so the server boots and serves tools/list on
a machine with no Ansys installed and even no ansys pip packages present.

Tools (3):
  ansys_modelcenter_status   : find_spec availability probe + ANSYS_ROOT check.
  ansys_modelcenter_launch   : soft-import the client and (best-effort) construct the
                           entry object; for PyAEDT this runs in a 30s thread so a
                           hung GUI/COM import cannot wedge the server.
  ansys_modelcenter_run      : accepts a 'command' string; returns the documented
                           client call to issue against a live product.

Env:
  ANSYS_ROOT : root of the Ansys installation on this host (edit in mcp.json).
               Used to locate the matching product engine + license.

"""

import concurrent.futures
import importlib
import importlib.util
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

# The client (Forji-Desk) launches this from the bundled venv. Keep the
# embedded stdlib zip on sys.path regardless of PYTHONHOME.
try:
    _real_prefix = os.path.dirname(sys.executable)
    _h = os.environ.get("PYTHONHOME")
    if _h and os.path.abspath(_h) != _real_prefix:
        del os.environ["PYTHONHOME"]
except Exception:
    pass

from mcp.server.fastmcp import FastMCP

SLUG = "modelcenter"
PRODUCT = "ModelCenter (multi-simulation optimization)"
TOP_IMPORT = "ansys.modelcenter"
ENTRY = None
KIND = "grpc"
PKG = "ansys-modelcenter-workflow"
ROOT_ENV = ""
ANSYS_ROOT = os.environ.get("ANSYS_ROOT", "").strip()
WORKDIR = os.environ.get("ANSYS_WORKDIR", _HERE)
os.environ.setdefault("AEDT_NO_GUI", "1")
os.environ.setdefault("ANSYS_AEDT_GUI_ENABLED", "0")

LAUNCH_TIMEOUT_S = 30.0


def _j(obj):
    return json.dumps(obj, indent=2, default=str)


def _ansys_root_block():
    return {
        "ansys_root_env": "ANSYS_ROOT",
        "ansys_root_set": bool(ANSYS_ROOT),
        "ansys_root": ANSYS_ROOT or None,
        "note": "Set ANSYS_ROOT to the Ansys install to run ModelCenter (multi-simulation optimization) for real "
                "(a valid, checked-out license is required).",
    }


def _distrib_path_prepared():
    if not ROOT_ENV:
        return True, "no distrib root env for this product"
    root = os.environ.get(ROOT_ENV, "").strip()
    if not root:
        return False, "set %s to the product install" % ROOT_ENV
    if not os.path.isdir(root):
        return False, "%s=%s does not exist" % (ROOT_ENV, root)
    added = []
    for base in (root, os.path.join(root, "shared_scripts"), os.path.join(root, "ansys_inc")):
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, _ in os.walk(base):
            if "site-packages" in dirnames:
                sp = os.path.join(dirpath, "site-packages")
                if sp not in sys.path:
                    sys.path.insert(0, sp)
                    added.append(sp)
                dirnames[:] = []
    if root not in sys.path:
        sys.path.insert(0, root)
    return True, ("added %d site-packages dir(s) from %s" % (len(added), root)) if added \
        else "no site-packages found under %s" % root


def soft_import():
    """Import TOP_IMPORT; never raise. Returns (mod, err_dict)."""
    try:
        spec = importlib.util.find_spec(TOP_IMPORT)
        if spec is None:
            return None, {"error": "ANSYS_PKG_MISSING", "package": PKG or TOP_IMPORT,
                          "hint": "offline bundle includes %s when present; the status tool reports availability" % (PKG or TOP_IMPORT)}
        if TOP_IMPORT in sys.modules:
            return sys.modules[TOP_IMPORT], None
        return importlib.import_module(TOP_IMPORT), None
    except ModuleNotFoundError:
        return None, {"error": "ANSYS_PKG_MISSING", "package": PKG or TOP_IMPORT,
                      "hint": "pip client package not importable in this venv"}
    except BaseException as exc:
        return None, {"error": "IMPORT_ERROR", "package": PKG or TOP_IMPORT,
                      "detail": str(exc)}


def is_importable():
    try:
        return importlib.util.find_spec(TOP_IMPORT) is not None
    except BaseException:
        return False


def _status():
    installed = is_importable()
    base = {"product": PRODUCT, "slug": SLUG, "kind": KIND,
            "pip_package": PKG, "top_import": TOP_IMPORT, "entry": ENTRY,
            "installed": installed}
    base.update(_ansys_root_block())
    if KIND == "distrib":
        ok, note = _distrib_path_prepared()
        base["root_env"] = ROOT_ENV
        base["distrib_path_prepared"] = ok
        base["note"] = (note or "") + " ; live run needs the product desktop + license."
    else:
        base["note"] = "installed = client pip package importable in this venv. A " \
            "matching Ansys install (ANSYS_ROOT) + valid license is required to " \
            "actually run ModelCenter (multi-simulation optimization)."
    if not installed and PKG:
        base["hint"] = "bundle ships the %s client; if 'installed' is false, the " \
            "venv is incomplete on this host" % PKG
    return _j(base)


def _launch():
    if KIND == "distrib":
        ok, note = _distrib_path_prepared()
        if not ok:
            return _j({"error": "ANSYS_SDK_NOT_FOUND", "hint": note, "slug": SLUG})
        mod, err = soft_import()
        if err:
            return _j({**err, "slug": SLUG})
        return _j({"product": PRODUCT, "slug": SLUG, "connected": True,
                   "imported": TOP_IMPORT,
                   "note": note + " ; live run of %s needs its desktop + license." % PRODUCT})
    if ENTRY is None:
        mod, err = soft_import()
        if err:
            return _j({**err, "slug": SLUG})
        return _j({"product": PRODUCT, "slug": SLUG, "connected": True, "imported": TOP_IMPORT,
                   "note": "import ok; see SKILL.md for the launch call."})
    if false:
        def factory():
            mod, err = soft_import()
            if mod is None:
                raise RuntimeError("client not importable")
            sub = importlib.import_module(TOP_IMPORT + ".core")
            cls = getattr(sub, ENTRY, None) or getattr(mod, ENTRY, None)
            if cls is None:
                raise RuntimeError("entry %s not found" % ENTRY)
            return cls()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="ansys") as ex:
            fut = ex.submit(factory)
            try:
                client = fut.result(timeout=LAUNCH_TIMEOUT_S)
                return _j({"product": PRODUCT, "slug": SLUG, "connected": True, "entry": ENTRY,
                           "client": type(client).__name__,
                           "note": "PyAEDT client constructed in a thread (30s guard). Drive modeler/solution; save() to persist."})
            except concurrent.futures.TimeoutError:
                fut.cancel()
                return _j({"error": "LAUNCH_TIMEOUT", "timeout_s": LAUNCH_TIMEOUT_S,
                           "hint": "AEDT desktop/COM import hung; AEDT_NO_GUI=1 is set."})
            except BaseException as exc:
                return _j({"connected": True, "imported": TOP_IMPORT, "entry": ENTRY,
                           "launch_error": str(exc),
                           "note": "import ok but construction failed - matching Ansys install/license not reachable."})
    mod, err = soft_import()
    if err:
        return _j({**err, "slug": SLUG})
    cls = getattr(mod, ENTRY, None)
    if cls is None:
        return _j({"product": PRODUCT, "slug": SLUG, "connected": True, "imported": TOP_IMPORT,
                   "entry_missing": ENTRY, "note": "entry %s not found on module at runtime." % ENTRY})
    try:
        inst = cls()
    except TypeError:
        return _j({"product": PRODUCT, "slug": SLUG, "connected": True, "imported": TOP_IMPORT, "entry": ENTRY,
                   "note": "%s requires constructor arguments; see SKILL.md." % ENTRY})
    except BaseException as exc:
        return _j({"product": PRODUCT, "slug": SLUG, "connected": True, "imported": TOP_IMPORT, "entry": ENTRY,
                   "launch_error": str(exc),
                   "note": "import ok but construction failed - matching Ansys install (ANSYS_ROOT) + license required."})
    return _j({"product": PRODUCT, "slug": SLUG, "connected": True, "imported": TOP_IMPORT, "entry": ENTRY,
               "client": type(inst).__name__,
               "note": "client constructed; a matching Ansys run + license is required for real work."})


def _run(command):
    return _j({
        "product": PRODUCT, "slug": SLUG, "kind": KIND, "command": command,
        "entry": ENTRY,
        "how": """import ansys.modelcenter   # client for a ModelCenter project""",
        **_ansys_root_block(),
        "note": "Best-effort runner. Pass a concrete command; a running Ansys process "
                "(ANSYS_ROOT) + valid license is required for real execution.",
    })


mcp = FastMCP("ansys-modelcenter")

@mcp.tool(name="ansys_modelcenter_status")
def status_tool():
    """Status probe (no side effects). Reports whether the pip client package is importable in this venv and whether ANSYS_ROOT is set. Always callable."""
    return _status()

@mcp.tool(name="ansys_modelcenter_launch")
def launch_tool():
    """Lazy import and connect/launch. Returns a JSON error (never an exception) when the SDK is missing, ANSYS_ROOT is unset, or the PyAEDT connect times out."""
    return _launch()

@mcp.tool(name="ansys_modelcenter_run")
def run_tool(command: str):
    """Best-effort runner. Pass a small command string; the tool returns the documented client call to issue against a live product."""
    return _run(command)


def main():
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()
